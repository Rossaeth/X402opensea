# X402opensea API (starter)

API-only starter for an OpenSea data gateway with x402 v2 payment middleware. It intentionally has no NFT marketplace frontend.

## Status and important limitations

- OpenSea routes are implemented as API proxy examples and require a valid `OPENSEA_API_KEY`.
- The paid endpoint is wired to x402 v2 middleware for Base and Solana when recipient addresses are configured. Confirm your chosen facilitator's `/supported` response for the exact network/scheme before production use.
- **Arc USDC is not enabled yet.** Do not guess the Arc CAIP-2 network identifier or USDC asset address. Enable it only after confirming official Arc network/token details and facilitator support, then add a verified EVM network registration and the correct asset configuration.
- MCP currently provides `initialize`, `tools/list`, and free collection lookup. The paid MCP tool only directs callers to the HTTP x402 endpoint; it does not itself sign or settle payment.
- This starter has not been deployed or live-tested against your API keys/facilitator. Run the checks below before production.

## Routes

- `GET /` — service metadata and enabled networks
- `GET /api/health` — health check
- `GET /api/openapi` — OpenAPI 3.1 JSON
- `GET /api/market/collection/:slug` — OpenSea collection metadata
- `GET /api/market/search?q=...` — sample collection search proxy (confirm upstream query behavior against current OpenSea docs)
- `GET /api/paid/floor?slug=...` — x402-protected paid collection stats, default price `$0.01`
- `POST /mcp` — minimal MCP JSON-RPC endpoint

## Run locally

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env` and set `OPENSEA_API_KEY`.
3. Review `FACILITATOR_URL`, `BASE_PAY_TO`, `SOLANA_PAY_TO`, and network settings.
4. Run:

```bash
npm install
npm run dev
```

Open `http://localhost:3000/api/health` and `http://localhost:3000/api/openapi`.

## Deployment

This includes a Vercel function entrypoint at `api/index.ts`. Configure all environment variables in Vercel before deploying. For other Node hosts, use `npm run build` then `npm start`.

## Security checklist before production

- Never commit `.env` or API secrets.
- Confirm the facilitator supports the exact networks and `exact` scheme using its `/supported` endpoint.
- Confirm the recipient address, stablecoin contract/mint, and token decimals on each network.
- Run a full x402 client payment test on each network, including failed payment and replay scenarios.
- Add rate limits, request logging without secrets, and monitoring.
- Verify the OpenSea endpoint/parameters against current official OpenSea API docs.
