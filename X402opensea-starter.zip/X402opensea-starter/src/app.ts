import express, { type Request, type Response } from 'express';
import cors from 'cors';
import { HTTPFacilitatorClient } from '@x402/core/server';
import { paymentMiddleware, x402ResourceServer } from '@x402/express';
import { ExactEvmScheme } from '@x402/evm/exact/server';
import { ExactSvmScheme } from '@x402/svm/exact/server';

const app = express();
app.disable('x-powered-by');
app.use(cors());
app.use(express.json({ limit: '1mb' }));

const env = (key: string, fallback = '') => process.env[key] ?? fallback;
const facilitatorUrl = env('FACILITATOR_URL', 'https://x402.org/facilitator');
const basePayTo = env('BASE_PAY_TO');
const solanaPayTo = env('SOLANA_PAY_TO');
const baseNetwork = env('BASE_NETWORK', 'eip155:8453');
const solanaNetwork = env('SOLANA_NETWORK', 'solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp');
const price = env('PAID_ENDPOINT_PRICE', '$0.01');

app.get('/', (_req, res) => res.json({
  name: 'X402opensea API',
  status: 'starter',
  message: 'API-only OpenSea data gateway. No marketplace UI.',
  docs: '/api/openapi',
  health: '/api/health',
  payment: { protocol: 'x402 v2', price, enabledNetworks: [basePayTo ? baseNetwork : null, solanaPayTo ? solanaNetwork : null].filter(Boolean), arc: 'disabled until network, USDC asset, and facilitator support are verified' }
}));

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'x402opensea-api', timestamp: new Date().toISOString() }));

app.get('/api/openapi', (_req, res) => {
  res.json({
    openapi: '3.1.0',
    info: { title: 'X402opensea API', version: '0.1.0', description: 'API-only OpenSea data gateway. Paid floor endpoint is protected by x402 v2 middleware.' },
    servers: [{ url: env('PUBLIC_BASE_URL', 'http://localhost:3000') }],
    paths: {
      '/api/health': { get: { summary: 'Health check', responses: { '200': { description: 'Service is available' } } } },
      '/api/market/collection/{slug}': { get: { summary: 'Fetch OpenSea collection metadata', parameters: [{ name: 'slug', in: 'path', required: true, schema: { type: 'string' } }], responses: { '200': { description: 'Collection data' }, '502': { description: 'OpenSea upstream error' } } } },
      '/api/market/search': { get: { summary: 'Search OpenSea collections', parameters: [{ name: 'q', in: 'query', required: true, schema: { type: 'string' } }], responses: { '200': { description: 'Search results' } } } },
      '/api/paid/floor': { get: { summary: 'Paid collection floor data', description: `Requires valid x402 v2 payment (${price}). Accepted networks are shown by GET /. Arc is not enabled in this starter.`, parameters: [{ name: 'slug', in: 'query', required: true, schema: { type: 'string' } }], responses: { '200': { description: 'Floor data after payment verification' }, '402': { description: 'Payment required' } } } },
      '/mcp': { post: { summary: 'MCP JSON-RPC discovery endpoint', description: 'Provides tools/list and free collection lookup tools. Paid data remains protected by the HTTP x402 endpoint.', responses: { '200': { description: 'JSON-RPC response' } } } }
    }
  });
});

const openSeaFetch = async (path: string) => {
  const key = env('OPENSEA_API_KEY');
  if (!key || key === 'replace_me') throw new Error('OPENSEA_API_KEY is not configured');
  const base = env('OPENSEA_API_BASE', 'https://api.opensea.io/api/v2');
  const upstream = await fetch(`${base}${path}`, { headers: { accept: 'application/json', 'x-api-key': key }, signal: AbortSignal.timeout(12000) });
  const body = await upstream.text();
  if (!upstream.ok) throw new Error(`OpenSea returned HTTP ${upstream.status}: ${body.slice(0, 300)}`);
  return JSON.parse(body) as unknown;
};

app.get('/api/market/collection/:slug', async (req, res) => {
  try {
    const slug = String(req.params.slug || '').trim();
    if (!/^[a-zA-Z0-9_-]{1,100}$/.test(slug)) return res.status(400).json({ error: 'Invalid collection slug' });
    res.json(await openSeaFetch(`/collections/${encodeURIComponent(slug)}`));
  } catch (error) { res.status(502).json({ error: 'OpenSea request failed', detail: error instanceof Error ? error.message : 'Unknown error' }); }
});

app.get('/api/market/search', async (req, res) => {
  try {
    const q = String(req.query.q ?? '').trim();
    if (!q || q.length > 100) return res.status(400).json({ error: 'Provide q (1-100 characters)' });
    res.json(await openSeaFetch(`/collections?chain=ethereum&limit=10&include_collabs=false` + `&search=${encodeURIComponent(q)}`));
  } catch (error) { res.status(502).json({ error: 'OpenSea search failed', detail: error instanceof Error ? error.message : 'Unknown error' }); }
});

// x402 payment middleware is enabled only for networks with recipient addresses configured.
// For production, verify the facilitator's /supported response before enabling any network.
const accepts: Array<{ scheme: 'exact'; price: string; network: string; payTo: string }> = [];
if (basePayTo) accepts.push({ scheme: 'exact', price, network: baseNetwork, payTo: basePayTo });
if (solanaPayTo) accepts.push({ scheme: 'exact', price, network: solanaNetwork, payTo: solanaPayTo });

if (accepts.length > 0) {
  const facilitatorClient = new HTTPFacilitatorClient({ url: facilitatorUrl });
  const resourceServer = new x402ResourceServer(facilitatorClient)
    .register(baseNetwork, new ExactEvmScheme())
    .register(solanaNetwork, new ExactSvmScheme());

  app.use(paymentMiddleware({
    'GET /api/paid/floor': { accepts, description: 'OpenSea collection floor data', mimeType: 'application/json' }
  }, resourceServer));
}

app.get('/api/paid/floor', async (req, res) => {
  try {
    const slug = String(req.query.slug ?? '').trim();
    if (!/^[a-zA-Z0-9_-]{1,100}$/.test(slug)) return res.status(400).json({ error: 'Provide a valid slug query parameter' });
    const data = await openSeaFetch(`/collections/${encodeURIComponent(slug)}/stats`);
    res.json({ paid: true, price, slug, data });
  } catch (error) { res.status(502).json({ error: 'Paid OpenSea request failed', detail: error instanceof Error ? error.message : 'Unknown error' }); }
});

// Minimal MCP JSON-RPC discovery. This is not an MCP payment client; callers pay the HTTP paid endpoint directly.
app.post('/mcp', async (req: Request, res: Response) => {
  const { jsonrpc, method, id, params } = req.body ?? {};
  if (jsonrpc !== '2.0' || typeof method !== 'string') return res.status(400).json({ jsonrpc: '2.0', id: id ?? null, error: { code: -32600, message: 'Invalid Request' } });
  if (method === 'initialize') return res.json({ jsonrpc: '2.0', id, result: { protocolVersion: '2025-03-26', capabilities: { tools: {} }, serverInfo: { name: 'x402opensea', version: '0.1.0' } } });
  if (method === 'notifications/initialized') return res.status(202).end();
  if (method === 'tools/list') return res.json({ jsonrpc: '2.0', id, result: { tools: [
    { name: 'opensea_collection', description: 'Fetch public OpenSea collection metadata by slug.', inputSchema: { type: 'object', properties: { slug: { type: 'string' } }, required: ['slug'] } },
    { name: 'opensea_paid_floor', description: 'Paid floor/stat endpoint. Call the HTTP endpoint /api/paid/floor?slug=... directly with x402 payment support.', inputSchema: { type: 'object', properties: { slug: { type: 'string' } }, required: ['slug'] } }
  ] } });
  if (method === 'tools/call') {
    const name = params?.name;
    const args = params?.arguments ?? {};
    if (name === 'opensea_collection' && typeof args.slug === 'string') {
      try { const result = await openSeaFetch(`/collections/${encodeURIComponent(args.slug)}`); return res.json({ jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: JSON.stringify(result) }] } }); }
      catch (e) { return res.json({ jsonrpc: '2.0', id, result: { isError: true, content: [{ type: 'text', text: e instanceof Error ? e.message : 'Unknown error' }] } }); }
    }
    if (name === 'opensea_paid_floor') return res.json({ jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: 'Paid tool is not executed inside MCP yet. Use GET /api/paid/floor?slug=... with an x402-compatible client to receive and settle the payment challenge.' }] } });
    return res.json({ jsonrpc: '2.0', id, error: { code: -32602, message: 'Unknown tool or invalid arguments' } });
  }
  return res.json({ jsonrpc: '2.0', id, error: { code: -32601, message: `Method not found: ${method}` } });
});

app.use((_req, res) => res.status(404).json({ error: 'Not found', docs: '/api/openapi' }));

export default app;
