# X402opensea — NFT marketplace + x402 V2 agent API

An English-language Next.js MVP with a dark marketplace UI, server-side OpenSea API proxy, x402 V2 paid endpoint for Base USDC, Arc USDC, and Solana USDC, NFT buy/sell preparation endpoints, transaction receipt verification, MCP tools, and OpenAPI documentation.

## What works in this MVP

- Website search UI uses live OpenSea search through `/api/market/search`.
- Server-side routes for collection metadata and collection listings.
- `GET /api/paid/floor?slug=<collection-slug>` is protected by x402 V2 exact payments. It supports Base USDC (`eip155:8453`), Arc mainnet USDC (`eip155:5042`), and Solana mainnet USDC (`solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp`) when the corresponding receiver is configured and the facilitator supports the network. Default price is `$0.01` per request.
- `POST /api/opensea/listings/actions` proxies OpenSea's listing preparation endpoint.
- `POST /api/opensea/orders/{chain}/{protocol}/listings` submits a signed Seaport order payload. The backend does not sign on behalf of a user.
- `GET /api/openapi` publishes an OpenAPI description for agent/tool registration.
- `/api/mcp` exposes a stateless Streamable HTTP MCP server with tools for OpenSea search, collection lookup, preparing listing actions, and submitting user-signed listings.
- The website includes an NFT URL inspector for supported OpenSea EVM asset links. It retrieves NFT metadata and attempts a best-effort current listing lookup.
- `POST /api/v1/nft/buy/prepare` requests OpenSea fulfillment transaction data from a current listing payload. Buyer must review, sign, and submit the returned transaction using PayBox or another compatible wallet.
- `POST /api/v1/nft/buy/confirm` verifies a submitted transaction receipt using a configured chain RPC.
- `POST /api/v1/nft/sell/prepare` prepares listing actions; `POST /api/v1/nft/sell/execute` submits an already wallet-signed Seaport order.
- MCP tools expose NFT inspection, buy preparation, sale preparation, signed listing submission, and transaction verification.
- This project does not itself connect to PayBox, store private keys, sign transactions, or broadcast a buyer transaction. PayBox must support the relevant wallet signing/submission flow and be configured as an MCP client.

## Endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/market/search?q=art` | OpenSea search |
| GET | `/api/market/collection/{slug}` | Collection metadata |
| GET | `/api/market/listings/{slug}?limit=20` | Collection listings |
| GET | `/api/paid/floor?slug=doodles-official` | x402 V2 paid collection snapshot; Base, Arc, or Solana USDC based on the payment challenge |
| GET | `/api/x402/networks` | Shows supported network identifiers and receiver configuration status |
| POST | `/api/v1/nft/inspect` | Inspect an OpenSea asset URL and attempt current listing lookup |
| POST | `/api/v1/nft/buy/prepare` | Request fulfillment transaction data for a buyer wallet |
| POST | `/api/v1/nft/buy/confirm` | Verify transaction receipt using configured RPC |
| POST | `/api/v1/nft/sell/prepare` | Prepare listing approval/signature steps |
| POST | `/api/v1/nft/sell/execute` | Submit a wallet-signed Seaport listing |
| POST | `/api/opensea/listings/actions` | Build the listing approval/signature steps |
| POST | `/api/opensea/orders/{chain}/{protocol}/listings` | Submit an already signed listing |
| GET | `/api/openapi` | OpenAPI schema for agent integration |
| GET/POST/DELETE | `/api/mcp` | Streamable HTTP MCP endpoint for AI agents |

## Setup

1. Install Node.js 20+.
2. Copy `.env.example` to `.env.local`.
3. Set `OPENSEA_API_KEY` to your OpenSea API key.
4. Set `X402_PAY_TO_BASE` and `X402_PAY_TO_ARC` to EVM receiver addresses you control on those networks. Set `X402_PAY_TO_SOLANA` to a Solana mainnet base58 address. A configured address only enables the network in the challenge; it does not prove facilitator support.
5. Run:

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## x402 / PayBox

The paid endpoint uses `@x402/next` V2, `@x402/evm`, and `@x402/svm` with the x402 facilitator. It can advertise Base, Arc, and Solana payment options only when their receiver addresses are configured and syntactically valid. A client/agent must make the initial request, read the exact `PAYMENT-REQUIRED` challenge (including `accepts` and resource metadata), create the proof with a compatible wallet holding USDC on the selected network, and retry the original URL with the returned payment header. Do not invent or hardcode the challenge fields. The service only considers the request paid after the facilitator/server verifies the proof. Confirm that your chosen facilitator supports all three network/scheme combinations before production use; code configuration alone is not proof of live settlement support.

For PayBox MCP, configure the deployed MCP endpoint (`https://YOUR_DOMAIN/api/mcp`) as a remote MCP server if your PayBox workspace supports custom remote servers. The OpenAPI document is available at `https://YOUR_DOMAIN/api/openapi`. Deploying the website alone does not automatically add it to PayBox's catalog; you may need to register/enable it in PayBox. The x402 endpoint is directly callable at `https://YOUR_DOMAIN/api/paid/floor?slug=...` and exposes the standard 402 challenge. Network configuration status is available at `https://YOUR_DOMAIN/api/x402/networks`.

## OpenSea buying/selling through an agent

1. Call `POST /api/v1/nft/inspect` with `{ "nft_url": "https://opensea.io/assets/base/0x.../123" }`.
2. Inspect the returned NFT metadata and best-effort listing response. A failed listing lookup is not proof that no listing exists; refresh and check the actual OpenSea listing.
3. Call `POST /api/v1/nft/buy/prepare` with `chain`, `protocol`, `buyer_address`, and the fresh `listing` object required by OpenSea's fulfillment API. The response contains fulfillment transaction data if OpenSea accepts the request.
4. Show the buyer the NFT, seller, price, currency, fees, chain, and transaction destination/calldata. Buyer must explicitly approve, sign, and submit through PayBox or another compatible wallet.
5. Call `POST /api/v1/nft/buy/confirm` with `chain` and `transaction_hash` to verify its receipt. Set the matching RPC environment variable first.
6. For selling, call `POST /api/v1/nft/sell/prepare`, complete approval actions and order signing in the seller wallet, then submit the signed Seaport order using `POST /api/v1/nft/sell/execute`.

**Important:** these endpoints are transaction preparation/submission helpers, not a complete autonomous trading wallet. PayBox compatibility is not confirmed by the presence of the MCP endpoint alone. Do not give the server a wallet private key. The current URL inspector supports standard OpenSea EVM asset URLs and does not yet guarantee listing resolution for every chain, order type, or URL format. Test on a supported test environment before mainnet use.

## Security notes

- Never use `NEXT_PUBLIC_OPENSEA_API_KEY`; never commit `.env.local`.
- Restrict/rate-limit proxy endpoints before production deployment.
- Keep marketplace actions user-authorized; do not place private keys in the server or ask agents to sign arbitrary orders.
- The public x402 facilitator and current SDK package APIs should be tested in staging before mainnet production. Set your own payment receiver and test with small amounts.

## Multi-chain x402 configuration

The protected collection endpoint supports these x402 V2 network identifiers:

- Base mainnet: `eip155:8453` (USDC)
- Arc mainnet: `eip155:5042` (USDC)
- Solana mainnet: `solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp` (USDC)

Set `X402_PAY_TO_BASE`, `X402_PAY_TO_ARC`, and `X402_PAY_TO_SOLANA`. Set Base price with `X402_PRICE_BASE`. Arc and Solana use explicit six-decimal USDC base-unit amounts via `X402_AMOUNT_ARC` and `X402_AMOUNT_SOLANA` (default `10000` = `0.01` USDC). Configure their USDC asset identifiers with `X402_USDC_ADDRESS_ARC` and `X402_USDC_MINT_SOLANA` if needed. A single EVM address can be reused for Base and Arc only if you control that address on both networks. Solana requires a Solana address. The code omits networks whose receiver address is missing or malformed. Use `/api/x402/networks` to inspect configuration. Before mainnet use, verify the facilitator advertises and settles all configured network/scheme pairs, then test with small amounts.
