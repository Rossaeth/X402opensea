const API = 'https://api.opensea.io/api/v2';
export async function openSeaFetch(path: string, init?: RequestInit) {
  const key = process.env.OPENSEA_API_KEY;
  if (!key) throw new Error('OPENSEA_API_KEY is not configured on the server');
  const response = await fetch(`${API}${path}`, {
    ...init,
    headers: { accept: 'application/json', 'content-type': 'application/json', 'x-api-key': key, ...(init?.headers || {}) },
    cache: 'no-store'
  });
  const body = await response.text();
  if (!response.ok) throw new Error(`OpenSea API returned ${response.status}: ${body.slice(0, 400)}`);
  return body ? JSON.parse(body) : {};
}
export function jsonError(message: string, status = 500) {
  return Response.json({ error: message }, { status });
}
