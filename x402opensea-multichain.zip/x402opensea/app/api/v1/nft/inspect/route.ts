import { openSeaFetch, jsonError } from '@/lib/opensea';
export const runtime = 'nodejs';

function parseOpenSeaAssetUrl(raw: string) {
  let url: URL;
  try { url = new URL(raw); } catch { throw new Error('nft_url must be a valid URL.'); }
  if (url.protocol !== 'https:' || !['opensea.io', 'www.opensea.io'].includes(url.hostname)) {
    throw new Error('Only HTTPS OpenSea NFT URLs are supported.');
  }
  const parts = url.pathname.split('/').filter(Boolean);
  if (parts[0] !== 'assets' || parts.length < 4) {
    throw new Error('Use an OpenSea asset URL in this format: https://opensea.io/assets/{chain}/{contract_address}/{token_id}.');
  }
  const [chain, contractAddress, tokenId] = parts.slice(1, 4);
  if (!/^[a-z0-9-]{1,32}$/i.test(chain) || !/^0x[a-fA-F0-9]{40}$/.test(contractAddress) || !/^[a-zA-Z0-9_-]{1,100}$/.test(tokenId)) {
    throw new Error('The OpenSea URL must include a supported chain, EVM contract address, and token ID.');
  }
  return { chain: chain.toLowerCase(), contractAddress, tokenId, canonicalUrl: `https://opensea.io/assets/${chain}/${contractAddress}/${tokenId}` };
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    if (typeof body?.nft_url !== 'string') return jsonError('Provide nft_url in the JSON body.', 400);
    const asset = parseOpenSeaAssetUrl(body.nft_url);
    const nft = await openSeaFetch(`/chain/${encodeURIComponent(asset.chain)}/contract/${encodeURIComponent(asset.contractAddress)}/nfts/${encodeURIComponent(asset.tokenId)}`);
    let bestListing: unknown = null;
    let listingNote: string | undefined;
    try {
      bestListing = await openSeaFetch(`/orders/${encodeURIComponent(asset.chain)}/seaport/listings?asset_contract_address=${encodeURIComponent(asset.contractAddress)}&token_ids=${encodeURIComponent(asset.tokenId)}&limit=1`);
    } catch { listingNote = 'NFT metadata was retrieved, but a best listing could not be confirmed. Refresh the listing before preparing a purchase.'; }
    return Response.json({ asset, nft, best_listing: bestListing, listing_note: listingNote, next_step: 'Call POST /api/v1/nft/buy/prepare with the current OpenSea listing payload and the buyer wallet address. A wallet signature is required to purchase.' });
  } catch (e: any) { return jsonError(e.message || 'Could not inspect the NFT.', e.message?.includes('OpenSea URL') || e.message?.includes('nft_url') || e.message?.includes('Only HTTPS') || e.message?.includes('Use an OpenSea') ? 400 : 502); }
}
