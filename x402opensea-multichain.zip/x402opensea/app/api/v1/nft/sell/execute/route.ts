import { openSeaFetch, jsonError } from '@/lib/opensea';
export const runtime = 'nodejs';
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { chain, protocol, parameters, protocol_address, signature } = body || {};
    if (typeof chain !== 'string' || !/^[a-z0-9-]{1,32}$/i.test(chain)) return jsonError('Provide a valid chain name.', 400);
    if (typeof protocol !== 'string' || !/^[a-z0-9-]{1,80}$/i.test(protocol)) return jsonError('Provide a valid protocol name, such as seaport.', 400);
    if (!parameters || typeof parameters !== 'object' || typeof protocol_address !== 'string' || typeof signature !== 'string' || !signature.startsWith('0x')) return jsonError('A wallet-signed order is required: parameters, protocol_address, and signature.', 400);
    const result = await openSeaFetch(`/orders/${encodeURIComponent(chain)}/${encodeURIComponent(protocol)}/listings`, { method: 'POST', body: JSON.stringify({ parameters, protocol_address, signature }) });
    return Response.json({ status: 'submitted', listing: result, instructions: 'OpenSea accepted the listing submission response. Check the returned order/listing status before presenting it as active.' });
  } catch (e: any) { return jsonError(e.message || 'Could not submit the signed NFT listing.', 502); }
}
