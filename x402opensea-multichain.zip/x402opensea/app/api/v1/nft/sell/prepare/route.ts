import { openSeaFetch, jsonError } from '@/lib/opensea';
export const runtime = 'nodejs';
export async function POST(req: Request) {
  try {
    const body = await req.json();
    if (!body || typeof body !== 'object' || Array.isArray(body)) return jsonError('Provide the OpenSea listing request as a JSON object.', 400);
    const result = await openSeaFetch('/listings/actions', { method: 'POST', body: JSON.stringify(body) });
    return Response.json({ status: 'prepared', listing_actions: result, signing_required: true, instructions: 'Complete any required NFT approvals and sign the Seaport order with the seller wallet. Then submit the signed order to POST /api/v1/nft/sell/execute.' });
  } catch (e: any) { return jsonError(e.message || 'Could not prepare NFT listing.', 502); }
}
