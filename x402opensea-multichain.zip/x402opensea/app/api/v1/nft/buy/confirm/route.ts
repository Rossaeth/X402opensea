import { jsonError } from '@/lib/opensea';
export const runtime = 'nodejs';
const RPC_ENV: Record<string, string> = { base: 'BASE_RPC_URL', ethereum: 'ETHEREUM_RPC_URL', polygon: 'POLYGON_RPC_URL', optimism: 'OPTIMISM_RPC_URL', arbitrum: 'ARBITRUM_RPC_URL', avalanche: 'AVALANCHE_RPC_URL' };
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const chain = typeof body?.chain === 'string' ? body.chain.toLowerCase() : '';
    const txHash = body?.transaction_hash;
    if (!/^0x[a-fA-F0-9]{64}$/.test(txHash || '')) return jsonError('Provide a valid transaction_hash.', 400);
    const envName = RPC_ENV[chain];
    if (!envName) return jsonError('Transaction confirmation is not configured for this chain.', 400);
    const rpcUrl = process.env[envName];
    if (!rpcUrl) return jsonError(`Set ${envName} on the server to verify transactions for ${chain}.`, 503);
    const rpc = await fetch(rpcUrl, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'eth_getTransactionReceipt', params: [txHash] }), cache: 'no-store' });
    if (!rpc.ok) return jsonError('The configured blockchain RPC request failed.', 502);
    const data = await rpc.json();
    if (data.error) return jsonError('The blockchain RPC returned an error.', 502);
    const receipt = data.result;
    if (!receipt) return Response.json({ status: 'pending', chain, transaction_hash: txHash, confirmed: false });
    const success = receipt.status === '0x1';
    return Response.json({ status: success ? 'confirmed' : 'failed', chain, transaction_hash: txHash, confirmed: success, block_number: receipt.blockNumber, receipt });
  } catch { return jsonError('Could not verify the transaction receipt.', 502); }
}
