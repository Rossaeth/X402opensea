import { openSeaFetch, jsonError } from '@/lib/opensea';
export const runtime = 'nodejs';
export async function POST(req: Request) {
  try {
    const body = await req.json();
    if (typeof body?.chain !== 'string' || !/^[a-z0-9-]{1,32}$/i.test(body.chain)) return jsonError('Provide a valid OpenSea chain name.', 400);
    if (typeof body?.protocol !== 'string' || !/^[a-z0-9-]{1,80}$/i.test(body.protocol)) return jsonError('Provide the listing protocol, such as seaport.', 400);
    if (typeof body?.buyer_address !== 'string' || !/^0x[a-fA-F0-9]{40}$/.test(body.buyer_address)) return jsonError('Provide the buyer wallet address as buyer_address.', 400);
    if (!body?.listing || typeof body.listing !== 'object' || Array.isArray(body.listing)) return jsonError('Provide the current OpenSea listing object in listing. Never reuse stale listing data.', 400);
    const result = await openSeaFetch('/listings/fulfillment_data', { method: 'POST', body: JSON.stringify({ listing: { ...body.listing, chain: body.chain }, fulfiller: { address: body.buyer_address } }) });
    return Response.json({ status: 'prepared', chain: body.chain, buyer_address: body.buyer_address, fulfillment: result, signing_required: true, instructions: 'Review the returned transaction and total costs. The buyer must sign and submit it with their wallet/PayBox. This server does not sign or broadcast transactions.' });
  } catch (e: any) { return jsonError(e.message || 'Could not prepare NFT purchase.', 502); }
}
