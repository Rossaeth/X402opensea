export const runtime = 'nodejs';

const evmAddress = (value: string) => /^0x[a-fA-F0-9]{40}$/.test(value);
const solanaAddress = (value: string) => /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(value);

export async function GET() {
  const basePayTo = process.env.X402_PAY_TO_BASE || process.env.X402_PAY_TO || '';
  const arcPayTo = process.env.X402_PAY_TO_ARC || process.env.X402_PAY_TO || '';
  const solanaPayTo = process.env.X402_PAY_TO_SOLANA || '';
  return Response.json({
    protocol: 'x402 v2',
    note: 'configured means the receiver address passes basic syntax validation; facilitator support and settlement must be tested separately.',
    networks: [
      { name: 'Base', network: 'eip155:8453', asset: 'USDC', price: process.env.X402_PRICE_BASE || process.env.X402_PRICE || '$0.01', configured: evmAddress(basePayTo) },
      { name: 'Arc Mainnet', network: 'eip155:5042', asset: 'USDC', price: '$0.01', amount_base_units: process.env.X402_AMOUNT_ARC || '10000', asset_address: process.env.X402_USDC_ADDRESS_ARC || '0x3600000000000000000000000000000000000000', configured: evmAddress(arcPayTo) },
      { name: 'Solana Mainnet', network: 'solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp', asset: 'USDC', price: '$0.01', amount_base_units: process.env.X402_AMOUNT_SOLANA || '10000', asset_address: process.env.X402_USDC_MINT_SOLANA || 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', configured: solanaAddress(solanaPayTo) },
    ],
  });
}
