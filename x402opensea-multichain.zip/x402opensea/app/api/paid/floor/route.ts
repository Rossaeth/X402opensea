import { withX402, x402ResourceServer } from '@x402/next';
import { HTTPFacilitatorClient } from '@x402/core/server';
import { ExactEvmScheme } from '@x402/evm/exact/server';
import { ExactSvmScheme } from '@x402/svm/exact/server';
import { openSeaFetch, jsonError } from '@/lib/opensea';

export const runtime = 'nodejs';

// x402 V2 network identifiers (CAIP-2).
const NETWORKS = {
  base: 'eip155:8453',
  arc: 'eip155:5042',
  solana: 'solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp',
} as const;

const basePayTo = process.env.X402_PAY_TO_BASE || process.env.X402_PAY_TO || '';
const arcPayTo = process.env.X402_PAY_TO_ARC || process.env.X402_PAY_TO || '';
const solanaPayTo = process.env.X402_PAY_TO_SOLANA || '';
const basePrice = process.env.X402_PRICE_BASE || process.env.X402_PRICE || '$0.01';
const solanaAmount = process.env.X402_AMOUNT_SOLANA || '10000';
const solanaUsdcMint = process.env.X402_USDC_MINT_SOLANA || 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v';
const arcAmount = process.env.X402_AMOUNT_ARC || '10000';
const arcUsdcAddress = process.env.X402_USDC_ADDRESS_ARC || '0x3600000000000000000000000000000000000000';
const facilitator = new HTTPFacilitatorClient({
  url: process.env.X402_FACILITATOR_URL || 'https://x402.org/facilitator',
});

const server = new x402ResourceServer(facilitator)
  .register(NETWORKS.base, new ExactEvmScheme())
  .register(NETWORKS.arc, new ExactEvmScheme())
  .register(NETWORKS.solana, new ExactSvmScheme());

const handler = async (req: Request) => {
  const slug = new URL(req.url).searchParams.get('slug')?.trim();
  if (!slug || !/^[a-zA-Z0-9_-]{1,100}$/.test(slug)) {
    return jsonError('Pass a valid OpenSea collection slug using ?slug=', 400);
  }
  try {
    const data: any = await openSeaFetch(`/collections/${encodeURIComponent(slug)}`);
    return Response.json({
      source: 'opensea',
      slug,
      name: data.name,
      collection: data,
      marketplace_url: `https://opensea.io/collection/${slug}`,
    });
  } catch (e: any) {
    return jsonError(e.message || 'Could not fetch collection data', 502);
  }
};

const isEvmAddress = (value: string) => /^0x[a-fA-F0-9]{40}$/.test(value);
const isSolanaAddress = (value: string) => /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(value);
const accepts = [
  ...(isEvmAddress(basePayTo) ? [{ scheme: 'exact' as const, price: basePrice, network: NETWORKS.base, payTo: basePayTo, maxTimeoutSeconds: 300 }] : []),
  ...(isEvmAddress(arcPayTo) ? [{ scheme: 'exact' as const, price: { amount: arcAmount, asset: arcUsdcAddress, extra: { name: 'USDC', version: '2' } }, network: NETWORKS.arc, payTo: arcPayTo, maxTimeoutSeconds: 300 }] : []),
  ...(isSolanaAddress(solanaPayTo) ? [{ scheme: 'exact' as const, price: { amount: solanaAmount, asset: solanaUsdcMint }, network: NETWORKS.solana, payTo: solanaPayTo, maxTimeoutSeconds: 300 }] : []),
];

const paidHandler = withX402(
  handler,
  {
    accepts,
    description: 'Paid OpenSea collection snapshot for AI agents. Accepts exact USDC payments on Base, Arc, or Solana when supported by the configured facilitator.',
    mimeType: 'application/json',
  },
  server,
);

export async function GET(req: Request) {
  // Only advertise payment networks with a syntactically valid receiver configured.
  // The client still needs a compatible wallet and the facilitator must support the network.
  if (accepts.length === 0) {
    return Response.json({
      error: 'x402 payments are disabled until at least one valid receiver is configured.',
      required_environment: ['X402_PAY_TO_BASE', 'X402_PAY_TO_ARC', 'X402_PAY_TO_SOLANA'],
    }, { status: 503 });
  }
  return paidHandler(req);
}
