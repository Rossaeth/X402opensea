import { openSeaFetch, jsonError } from '@/lib/opensea';
export const runtime = 'nodejs';
export async function POST(req: Request, ctx: { params: Promise<{chain:string;protocol:string}> }) {
 const {chain,protocol}=await ctx.params;
 if(!/^[a-z0-9-]{1,32}$/i.test(chain)||!/^[a-z0-9-]{1,80}$/i.test(protocol)) return jsonError('Invalid chain or protocol',400);
 try { const body=await req.json(); if(!body?.parameters||!body?.protocol_address||!body?.signature) return jsonError('A signed Seaport order is required: parameters, protocol_address, signature.',400); return Response.json(await openSeaFetch(`/orders/${encodeURIComponent(chain)}/${encodeURIComponent(protocol)}/listings`,{method:'POST',body:JSON.stringify(body)})); }
 catch(e:any){return jsonError(e.message||'OpenSea listing submission failed',502)}
}
