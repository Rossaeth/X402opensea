import { openSeaFetch, jsonError } from '@/lib/opensea';
export const runtime = 'nodejs';
export async function POST(req: Request) {
 try { const body=await req.json(); if(!body || typeof body !== 'object' || Array.isArray(body)) return jsonError('Provide the exact JSON body required by OpenSea listing actions.',400); return Response.json(await openSeaFetch('/listings/actions',{method:'POST',body:JSON.stringify(body)})); }
 catch(e:any){return jsonError(e.message||'Could not prepare listing actions',502)}
}
