import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { z } from 'zod';
import { openSeaFetch } from '@/lib/opensea';
export const runtime = 'nodejs';
async function handle(req: Request) {
  const server = new McpServer({ name: 'x402opensea', version: '0.1.0' });
  server.tool('search_opensea', 'Search OpenSea collections, NFTs, tokens, and accounts.', { query: z.string().min(1).max(120) }, async ({ query }) => {
    try { const data = await openSeaFetch(`/search?query=${encodeURIComponent(query)}&limit=20`); return { content: [{ type: 'text', text: JSON.stringify(data) }] }; }
    catch (e: any) { return { isError: true, content: [{ type: 'text', text: e.message || 'OpenSea search failed' }] }; }
  });
  server.tool('get_opensea_collection', 'Get OpenSea collection metadata using its slug.', { slug: z.string().regex(/^[a-zA-Z0-9_-]{1,100}$/) }, async ({ slug }) => {
    try { const data = await openSeaFetch(`/collections/${encodeURIComponent(slug)}`); return { content: [{ type: 'text', text: JSON.stringify(data) }] }; }
    catch (e: any) { return { isError: true, content: [{ type: 'text', text: e.message || 'Collection lookup failed' }] }; }
  });
  server.tool('prepare_opensea_listing', 'Prepare OpenSea listing actions. Wallet approvals and Seaport order signing must be performed by the user wallet; this tool does not sign.', { request_body: z.record(z.string(), z.unknown()) }, async ({ request_body }) => {
    try { const data = await openSeaFetch('/listings/actions', { method: 'POST', body: JSON.stringify(request_body) }); return { content: [{ type: 'text', text: JSON.stringify(data) }] }; }
    catch (e: any) { return { isError: true, content: [{ type: 'text', text: e.message || 'Listing preparation failed' }] }; }
  });
  server.tool('submit_signed_opensea_listing', 'Submit a signed Seaport listing order. Requires a real wallet-generated signature; never provide a fabricated signature.', { chain: z.string().min(1).max(32), protocol: z.string().min(1).max(80), parameters: z.record(z.string(), z.unknown()), protocol_address: z.string().min(1), signature: z.string().min(1) }, async ({ chain, protocol, parameters, protocol_address, signature }) => {
    try { const data = await openSeaFetch(`/orders/${encodeURIComponent(chain)}/${encodeURIComponent(protocol)}/listings`, { method: 'POST', body: JSON.stringify({ parameters, protocol_address, signature }) }); return { content: [{ type: 'text', text: JSON.stringify(data) }] }; }
    catch (e: any) { return { isError: true, content: [{ type: 'text', text: e.message || 'Listing submission failed' }] }; }
  });
  server.tool('inspect_opensea_nft', 'Inspect an OpenSea NFT asset URL and retrieve NFT metadata plus a best-effort current listing lookup. Does not buy or sign.', { nft_url: z.string().url().max(500) }, async ({ nft_url }) => {
    try {
      const url = new URL(nft_url);
      if (url.protocol !== 'https:' || !['opensea.io', 'www.opensea.io'].includes(url.hostname)) throw new Error('Only HTTPS OpenSea URLs are supported.');
      const parts = url.pathname.split('/').filter(Boolean);
      if (parts[0] !== 'assets' || parts.length < 4) throw new Error('Use /assets/{chain}/{contract_address}/{token_id}.');
      const [chain, contract, tokenId] = parts.slice(1, 4);
      if (!/^0x[a-fA-F0-9]{40}$/.test(contract)) throw new Error('The asset URL must contain an EVM contract address.');
      const nft = await openSeaFetch(`/chain/${encodeURIComponent(chain)}/contract/${encodeURIComponent(contract)}/nfts/${encodeURIComponent(tokenId)}`);
      let listing: unknown = null;
      try { listing = await openSeaFetch(`/orders/${encodeURIComponent(chain)}/seaport/listings?asset_contract_address=${encodeURIComponent(contract)}&token_ids=${encodeURIComponent(tokenId)}&limit=1`); } catch { /* metadata can still be useful without listing data */ }
      return { content: [{ type: 'text', text: JSON.stringify({ chain, contract_address: contract, token_id: tokenId, nft, best_listing: listing, next_step: 'Use POST /api/v1/nft/buy/prepare with fresh listing data and the buyer wallet address. Wallet signing is required.' }) }] };
    } catch (e: any) { return { isError: true, content: [{ type: 'text', text: e.message || 'NFT inspection failed.' }] }; }
  });
  server.tool('prepare_opensea_nft_purchase', 'Prepare OpenSea fulfillment transaction data for a buyer. Requires fresh listing data and buyer wallet address. Never signs or broadcasts.', { chain: z.string().min(1).max(32), protocol: z.string().min(1).max(80), buyer_address: z.string().regex(/^0x[a-fA-F0-9]{40}$/), listing: z.record(z.string(), z.unknown()) }, async ({ chain, protocol, buyer_address, listing }) => {
    try { const result = await openSeaFetch('/listings/fulfillment_data', { method: 'POST', body: JSON.stringify({ listing: { ...listing, chain }, fulfiller: { address: buyer_address } }) }); return { content: [{ type: 'text', text: JSON.stringify({ status: 'prepared', fulfillment: result, signing_required: true, instructions: 'Buyer must review, sign, and submit the returned transaction using PayBox or another compatible wallet.' }) }] }; }
    catch (e: any) { return { isError: true, content: [{ type: 'text', text: e.message || 'Purchase preparation failed.' }] }; }
  });
  server.tool('verify_nft_purchase_transaction', 'Verify a submitted NFT purchase transaction receipt. Requires chain RPC environment configuration.', { chain: z.enum(['base', 'ethereum', 'polygon', 'optimism', 'arbitrum', 'avalanche']), transaction_hash: z.string().regex(/^0x[a-fA-F0-9]{64}$/) }, async ({ chain, transaction_hash }) => {
    const rpcEnv: Record<string, string> = { base: 'BASE_RPC_URL', ethereum: 'ETHEREUM_RPC_URL', polygon: 'POLYGON_RPC_URL', optimism: 'OPTIMISM_RPC_URL', arbitrum: 'ARBITRUM_RPC_URL', avalanche: 'AVALANCHE_RPC_URL' };
    try { const rpcUrl = process.env[rpcEnv[chain]]; if (!rpcUrl) throw new Error(`Configure ${rpcEnv[chain]} on the server.`); const response = await fetch(rpcUrl, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'eth_getTransactionReceipt', params: [transaction_hash] }), cache: 'no-store' }); const data = await response.json(); if (!response.ok || data.error) throw new Error('Blockchain RPC request failed.'); const receipt = data.result; return { content: [{ type: 'text', text: JSON.stringify({ status: !receipt ? 'pending' : receipt.status === '0x1' ? 'confirmed' : 'failed', chain, transaction_hash, confirmed: Boolean(receipt && receipt.status === '0x1'), receipt }) }] }; }
    catch (e: any) { return { isError: true, content: [{ type: 'text', text: e.message || 'Transaction verification failed.' }] }; }
  });
  server.tool('prepare_opensea_nft_sale', 'Prepare listing approval/signature steps through OpenSea. Seller must approve and sign with their wallet.', { request_body: z.record(z.string(), z.unknown()) }, async ({ request_body }) => {
    try { const result = await openSeaFetch('/listings/actions', { method: 'POST', body: JSON.stringify(request_body) }); return { content: [{ type: 'text', text: JSON.stringify({ status: 'prepared', listing_actions: result, signing_required: true }) }] }; }
    catch (e: any) { return { isError: true, content: [{ type: 'text', text: e.message || 'Sale preparation failed.' }] }; }
  });
  server.tool('submit_signed_opensea_sale', 'Submit a wallet-signed Seaport listing to OpenSea. Never fabricate a signature.', { chain: z.string().min(1).max(32), protocol: z.string().min(1).max(80), parameters: z.record(z.string(), z.unknown()), protocol_address: z.string().min(1), signature: z.string().min(1) }, async ({ chain, protocol, parameters, protocol_address, signature }) => {
    try { const result = await openSeaFetch(`/orders/${encodeURIComponent(chain)}/${encodeURIComponent(protocol)}/listings`, { method: 'POST', body: JSON.stringify({ parameters, protocol_address, signature }) }); return { content: [{ type: 'text', text: JSON.stringify({ status: 'submitted', listing: result }) }] }; }
    catch (e: any) { return { isError: true, content: [{ type: 'text', text: e.message || 'Sale submission failed.' }] }; }
  });
  const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
  await server.connect(transport);
  return transport.handleRequest(req);
}
export const GET = handle;
export const POST = handle;
export const DELETE = handle;
