import { openSeaFetch, jsonError } from '@/lib/opensea';
export const runtime = 'nodejs';
export async function GET(req: Request, ctx: { params: Promise<{slug:string}> }) {
 const {slug}=await ctx.params; const url=new URL(req.url); const limit=Math.min(50,Math.max(1,Number(url.searchParams.get('limit')||20))); const next=url.searchParams.get('next');
 if(!/^[a-zA-Z0-9_-]{1,100}$/.test(slug)) return jsonError('Invalid collection slug',400);
 const params=new URLSearchParams({limit:String(limit)}); if(next)params.set('next',next);
 try{return Response.json(await openSeaFetch(`/listings/collection/${encodeURIComponent(slug)}/all?${params}`));}catch(e:any){return jsonError(e.message||'OpenSea listings failed',502)}
}
