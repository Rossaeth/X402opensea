import { openSeaFetch, jsonError } from '@/lib/opensea';
export const runtime = 'nodejs';
export async function GET(req: Request, ctx: { params: Promise<{slug:string}> }) {
 const {slug}=await ctx.params; if(!/^[a-zA-Z0-9_-]{1,100}$/.test(slug)) return jsonError('Invalid collection slug',400);
 try{return Response.json(await openSeaFetch(`/collections/${encodeURIComponent(slug)}`));}catch(e:any){return jsonError(e.message||'OpenSea request failed',502)}
}
