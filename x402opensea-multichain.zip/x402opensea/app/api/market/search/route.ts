import { openSeaFetch, jsonError } from '@/lib/opensea';
export const runtime = 'nodejs';
export async function GET(req: Request) {
  const url = new URL(req.url); const q = url.searchParams.get('q')?.trim();
  if (!q) return jsonError('Missing q search parameter', 400);
  if (q.length > 120) return jsonError('Search query too long', 400);
  try { return Response.json(await openSeaFetch(`/search?query=${encodeURIComponent(q)}&limit=24`)); }
  catch (e: any) { return jsonError(e.message || 'OpenSea search failed', e.message?.includes('not configured') ? 503 : 502); }
}
