import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'X402 OpenSea | Agent-ready NFT market', description: 'Explore OpenSea NFT listings and x402-paid agent endpoints.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
